HWMonitor Readme file
----------------------

Version 1.67
July 2026
Contact : cpuz@cpuid.com
Web page: https://www.cpuid.com/softwares/hwmonitor.html
CPUID SDK : https://www.cpuid-pro.com/products-system-monitoring-kit.php

History
-------
--------------------------------------------------------------------------------------------------
1.67 - July 2026
- Corsair HX1000i/HX1200i/HX1500i PSUs.
- NZXT Kraken Z, Kraken Plus and Kraken Elite AIOs.
- AMD Radeon RX 9050 (Navi 44).
- NVIDIA GPUs Crossbar clock.

--------------------------------------------------------------------------------------------------
1.66 - July 2026
- Improved hotspot temperature report on AMD Radeon RX9000 GPUs.
- Transparent graph window.

--------------------------------------------------------------------------------------------------
1.65.1 - July 2026
- Hotspot temperature on NVIDIA RTX 50x0 GPUs (fixed in 1.65.1).
- Preliminary support of Lisuan 7G100 GPU.

--------------------------------------------------------------------------------------------------
1.64 - June 2026
- Intel Arc G3 & G3 Extreme (Panther Lake).
- Intel Core Ultra 5 250KF Plus (Arrow Lake Refresh).
- AMD Ryzen 7 7700X3D (Raphael).
- AMD Ryzen AI Max+ 495, 492, 488 (Gorgon Halo).
- AMD Ryzen AI Max 490, 485 (Gorgon Halo).
- AMD Ryzen AI Max PRO 495, 490, 485, 480 (Gorgon Halo).
- AMD Ryzen 9 9950X3D2 (Granite Ridge).
- AMD Ryzen 9 PRO 9965X3D, PRO 9945 (Granite Ridge).
- AMD Ryzen 7 PRO 9755, PRO 9745 (Granite Ridge).
- AMD Ryzen 5 PRO 9645 (Granite Ridge).
- AMD Ryzen AI 7/PRO 450G/GE (Gorgon Point 2).
- AMD Ryzen AI 5/PRO 440G/GE (Gorgon Point 2).
- AMD Ryzen AI 5/PRO 435G/GE (Gorgon Point 3).
- Support of HUDIMM and HSODIMM memory modules.
- New themes.
- New real-time graphs.

--------------------------------------------------------------------------------------------------
1.63 - April 2026
- Intel Core Ultra 7 270K Plus and Ultra 5 250K Plus (Arrow Lake Refresh).
- Intel Core 7 360 and 350 (Wildcat Lake).
- Intel Core 5 330, 320 and 315 (Wildcat Lake).
- Intel Core 3 304 (Wildcat Lake).
- Intel Core 9 273PQE, 273PTE, 273PE (Bartlett Lake).
- Intel Core 7 253PQE, 253PTE, 253PE, 251TE, 251E (Bartlett Lake).
- Intel Core 5 223PQE, 223PTE, 223PE, 221TE, 221E, 213PTE, 213PE, 211TE, 211E (Bartlett Lake).
- Intel Core 3 201TE, 201E (Bartlett Lake).
- Intel Core i7-13645HX (Raptor Lake).
- Preliminary support of Intel Nova Lake.
- AMD Ryzen 9 9950X3D2 (Granite Ridge).
- AMD Ryzen AI Max+ 392 (Strix Halo).
- AMD Ryzen AI 7/PRO 450G/E, AI 5/PRO 440G/E & 435G/E (Kraken Point 2).
- VR temperatures on Intel Arc B580/570.
- Intel Arc Pro B70 and B65 (BMG-G31).
- Intel Arc Pro B60 and B50 (BMG-G21).
- CQDIMM (4-ranks CUDIMM) memory support.

--------------------------------------------------------------------------------------------------
1.62 - February 2026
- Improved Intel Voltage Regulator monitoring.
- Support of Thermal Grizzly WireView PRO II monitoring device.
- Monitoring of MSI MEG Ai1000P, Ai1300P and Ai1600T PSUs.
- Preliminary support of Intel Wildcat Lake.
- AMD Ryzen AI 9 HX 470.
- New CSV logging feature.

--------------------------------------------------------------------------------------------------
1.61 - December 2025
- AMD Ryzen 7 9850X3D (Granite Ridge).
- AMD Ryzen 5 7500X3D (Raphael).
- Preliminary support of AMD Medusa Point.
- Intel Arrow Lake Refresh.

--------------------------------------------------------------------------------------------------
1.60 - October 2025
- Intel Core Ultra X9 388H, Core Ultra X7 368H and 358H, Core Ultra X5 338H (Panther Lake-H).
- Intel Core Ultra 9 375H, Core Ultra 7 355H and 345H, Core Ultra 5 325H (Panther Lake-H).
- Intel Core Ultra 7 360U, Core Ultra 5 350U and 340U, Core Ultra 3 320U (Panther Lake-U).
- Intel Core Ultra 3 205 (Arrow Lake).
- Intel Core 3/5/7 2xxE (Bartlett Lake).
- Intel Core i5 110 (Comet Lake).
- AMD Ryzen 5 5600F (Vermeer).
- AMD Ryzen 9 PRO 9945, Ryzen 7 PRO 9745, Ryzen 5 PRO 9645 (Granite Ridge).
- Improved support of AMD Ryzen AI 7 350 and Ryzen AI 5 340 (Kraken Point).

--------------------------------------------------------------------------------------------------
1.59 - August 2025
- AMD Ryzen Z2 and Z2 Extreme (Strix Point).
- AMD Ryzen Threadripper 9000 (Shimada Peak).
- NVIDIA RTX 5060 Ti (GB206), RTX 5050 (GB207).

--------------------------------------------------------------------------------------------------
1.58 - June 2025
- AMD Radeon RX 9060 XT (Navi 44).
- NVIDIA RTX 5060 (GB206).

--------------------------------------------------------------------------------------------------
1.57 - April 2025
- AMD Ryzen 9 8945HX, 8940HX, Ryzen 7 8840HX, 8745HX (Dragon Range refresh).
- AMD Ryzen AI Max+ 395 & AI Max+ PRO 395, Ryzen AI Max 390 & AI Max 385 (Strix Halo).
- AMD Ryzen AI 7 350, Ryzen AI 5 340  (Kraken Point).
- AMD Ryzen 7 5705G, 5705GE, Ryzen 5 5605G, 5605GE, Ryzen 3 5305G, 5305GE (Cezanne).
- AMD Radeon RX 9070 XT & 9070 (Navi 48).
- Zhaoxin KaiXian KX-U6780A and KX-U6580 (LuJiaZui, 8 cores).
- NVIDIA RTX 5070 Ti (GB203) & 5070 (GB205), RTX 5060 Ti (GB206).
- NVIDIA PCI-E error counters.
- Fix NVIDIA GPU temperature bug (drivers GeForce 576.02).
- Asus RTX Astral 5080 & 5090 12VHPWR per-pin currents and additional temperatures.

--------------------------------------------------------------------------------------------------
1.56 - February 2025
- Intel Arc B580 GPU.
- Intel Arrow Lake-U preliminary support.
- Improved support of Intel Lunar Lake.
- Intel Q870, B860, H810, W880, HM870, WM890, WM880 chipsets.
- Intel Core Ultra 9 285HX, Ultra 7 275HX/265HX/255HX, Ultra 5 245HX/235HX (Arrow Lake-HX).
- Intel Core Ultra 9 285H, Ultra 7 265H/255H, Ultra 5 235H/225H (Arrow Lake-H).
- Intel Core 7 160HL, 150HL, 160UL, 150UL, 150U (Raptor Lake).
- Intel Core 5 130HL, 120HL, 130UL, 120U (Raptor Lake).
- Intel Core 3 100HL, 100UL, 100U (Raptor Lake).
- AMD Ryzen 9 9955HX3D, 9955HX, 9950HX3D, 9950HX, 9850HX, 9845HX (Fire Range).
- AMD Ryzen 7 9800X3D (Granite Ridge).
- AMD X870/B840 chipsets.
- NVIDIA RTX 5090 & 5080 GPUs.
- CAMM2 memory modules type.
- CUDIMM DDR5 memory.
- Remember window position.

--------------------------------------------------------------------------------------------------
1.55 - September 2024
- Added Intel Voltage Regulator (VR) monitoring.
- Added GPU memory utilization in MBytes.
- Added CPU and SOC BCLK.
- Added Intel ICC Max.
- Improved support of AMD Granite Ridge and Strix Point.
- Improved support of Intel Arrow Lake clock granularity.
- Intel Core Ultra 5 235, 225 & 225F (Arrow Lake).
- Intel Core i9 14901KE & 14901E, Core i7 14701KE, Core i5 14501E & 14401E/F (Raptor Lake).

--------------------------------------------------------------------------------------------------
1.54 - July 2024
- AMD Ryzen 9 9950X (16C/32T), 9900X (12C/24T), Ryzen 7 9700X (8C/16T) and Ryzen 5 9600X (6C/12T) Granite Ridge (Zen 5).
- AMD Ryzen AI 9 HX 375 (4x Zen 5 + 8x Zen 5c), Ryzen AI 9 365 (4x Zen 5 + 6x Zen 5c) Strix Point APUs.
- AMD Ryzen 9 8945H, Ryzen 7 8845HS (Hawk Point).
- Intel Core Ultra 9 285K & 275, Core Ultra 7 265K & 255, Core Ultra 5 245K & 240 (Arrow Lake). 
- Intel Core Ultra 9 288V ; Ultra 7 268V, 266V, 258V, 256V ; Ultra 5 236V, 228V, 2266V (Lunar Lake).
- AMD Radeon RX 7600 XT (Navi 33 XT).

--------------------------------------------------------------------------------------------------
1.53 - February 2024
- Improved support of Intel Meteor Lake and preliminary support of Arrow Lake.
- AMD Ryzen 7 8700G, Ryzen 5 8600G, Ryzen 5 8500G (Phoenix).
- AMD Hawk Point and Hawk Point 2 (Zen 4/Zen 4c).
- AMD Radeon RX 7600 XT (Navi 33 XT).
- NVIDIA RTX 4070 SUPER (AD104-350), RTX 4070 Ti SUPER (AD103-275), RTX 4080 SUPER (AD103-400).
- Adds NPU utilization.
- Marks fastest cores.

--------------------------------------------------------------------------------------------------
1.52 - September 2023
- Intel Core i9-14900K/KF (24c), Core i7-14700K/KF (20c),  Core i5-14600K/KF (14c).
- Support of Intel Core 3, 5, 7 and Core Ultra 5, 7, 9 new branding.
- Preliminary support for Intel Meteor Lake.
- AMD Radeon RX 7800 XT and 7700 XT (Navi 32).

--------------------------------------------------------------------------------------------------
1.51 - June 2023
- AMD Ryzen Z1 and Z1 Extreme.
- AMD Ryzen 9 7940H & HS, Ryzen 7 7840HS (Phoenix).
- AMD Dragon Range Ryzen 9 7945HX (16c/55-75W), 7845HX (12c/45-75W), Ryzen 7 7745HX (8c/45-75W), 7645HX (6c/45-75W).
- Intel Core i9 13980HX, 13900HX, 13900HK, Core i7 13700H, 13650HX, Core i5 13500HX, 13420H.
- Intel N97, N95 and N50 (ADL-N, 6W to 15W).
- Zhaoxin C-1080 IGP (KX-6000G).
- Zhaoxin KH-40000 YongFeng (12/16/32c).
- NVIDIA RTX 4060 Ti (AD106-350).
- AMD Radeon RX 7600 (Navi 33 XL).

--------------------------------------------------------------------------------------------------
1.50.1 - March 2023
- Loading dialog (1.50.1).
- Fix RTX 4090/4080/4070 detection bug (1.50.1).
- Fix DMI crash bug (1.50.1).
- Preliminary support for AMD Storm Peak platform.
- Improved support of AMD Radeon 6950 XT.
- Zhaoxin KX-6000G/4 CPU.
- Intel Xeon Sapphire Rapids platform.
- Intel N100 and N200 (ADL-N).
- Intel Core i3 N300 and N305 (ADL-N).
- Intel Core i5 13450HX, 13500HX, Core i7 13650HX, 13700HX (55W).

--------------------------------------------------------------------------------------------------
1.49 - January 2023
- Intel Core i9 13900KS.
- AMD Ryzen 9 7950X3D, 7900X3D, Ryzen 7 7800X3D.
- AMD Ryzen 9 7900, Ryzen 7 7700, Ryzen 5 7600.
- AMD Radeon 7900 XT/XTX.
- NVIDIA RTX RTX 4070 Ti.
- DDR5 VDD/VDDQ/VDDP,VOUT 1.8V & 1.0 voltages.

--------------------------------------------------------------------------------------------------
1.48 - December 2022
- NVIDIA GPU power rails.
- NVIDIA RTX 4080 16GB (AD103).
- AMD Ryzen 5 7535H (zen3+, 6C/12T), Ryzen 7 7735HS (zen3+, 8C/16T).
- AMD Athlon Gold 7220U, Ryzen 3 7320U, Ryzen 5 7520U (MDN-A0, 15W).
- Intel Core i5 13450HX, 13500HX, Core i7 13650HX, 13700HX (55W).
- Intel Core i5 13420H, 13500H and Core i7 13620H (RPL, 45W).
- Intel Core i7 12850HX (8P+8E, 55W).
- Preliminary support for AMD Radeon RX 7900 XT/XTX (Navi 31).

--------------------------------------------------------------------------------------------------
1.47 - October 2022
- Intel Core i9-13900/K/F/KF, Core i7-13700/K/F/KF, Core i5-13600/K/F/KF, Core i5-13500, Core i5-13400 and Core i3-13100.
- Intel Core i9 13900HK, Core i7 13700H.
- Intel Z790 and B760 chipsets.
- Intel ARC A770, A750, A580 (ACM-G10) and A380 (ACM-G11) GPUs.
- AMD Ryzen 9 7950X, Ryzen 9 7900X, Ryzen 7 7700X, Ryzen 5 7600X.
- AMD X670E/B650 chipsets.
- AMD Radeon RX 6950 XT (Navi 21 KXTX), RX 6750 XT (Navi 22 KXT), RX 6650 XT (Navi 23 KXT) and RX 6400 (Navi 24 XL).
- NVIDIA RTX 4090 GPU.
- Gigabyte AORUS 1200W Platinium PSU monitoring.

--------------------------------------------------------------------------------------------------
1.46 - April 2022
- Improved sensors organization in tree display.
- New "max" sensors for CPU VID, CPU core temperatures and CPU core powers.
- Glenfly Arise-GT10C0 GPU (Arise).
- Intel Core i9-12900T, Core i5-12600T (35W).
- Intel Core i7-1280P/1270P/1260P, Core i5-1250P/1240P, Core i3-1220P (28W).
- Intel Core i7-1265U/1255U, Core i5 1245U/1235U, Core i3 1215U (15W).
- Intel Core i7-1260U/1250U, Core i5 1240U/1230U, Core i3 1210U (9W).
- Intel Atom x6427FE, x6425RE, x6425E, x6414RE, x6413E, x6212RE, x6211E, x6200FE (EHL, FCBGA1493).
- Intel Pentium J6425, N6415 (EHL, FCBGA1493).
- Intel Celeron J6413, N6211 (EHL, FCBGA1493).
- Intel Xeon Platinum, Gold and Silver "Ice Lake-SP" (10nm, FCLGA4189).
- Preliminary support for Intel Raptor Lake (13th gen).
- Preliminary support for Intel ARC 3/5/7 (DG2).
- AMD Ryzen 9 6980HX, 6900HX, Ryzen 7 6800H, Ryzen 5 6600H (45W).
- AMD Ryzen 9 6980HS, 6900HS, Ryzen 7 6800HS, Ryzen 5 6600HS (35W).
- AMD Ryzen 7 5800X3D.
- AMD Ryzen 7 5700X, Ryzen 5 5600/5500.
- AMD Ryzen 7 6800U, Ryzen 5 6600U (15-28W).
- AMD Ryzen 7 5825U, Ryzen 5 5625U, Ryzen 3 5425U (15W).
- AMD Ryzen 7 4800U (15W).
- AMD Ryzen 3 5300GE, Ryzen 3 PRO 5350GE, Ryzen 5 PRO 5650GE, Ryzen 7 PRO 5750GE (CZN).
- AMD Rembrandt & Raphael APUs (RDNA2).
- Preliminary support for AMD Phoenix (Zen 4, FP8).
- Preliminary support for AMD Raphael (Zen 4).
- AMD Radeon RX 6500 XT (Navi 24 XT), RX 6400 (Navi 24 XL).
- AMD Radeon RX 6850M XT (Navi 22).
- AMD RX 6800S, RX 6700S, RX 6650M, RX 6650M XT (Navi 23).
- NVIDIA GeForce RTX 3090 Ti (GA102-350, 450W).

--------------------------------------------------------------------------------------------------
1.45 - November 2021
- Intel 12th gen Alder Lake processors, Z6xx platform and DDR5 memory.
- AMD Radeon 6600XT GPU.
- Hard disks activity and read/write speeds.

--------------------------------------------------------------------------------------------------
1.44 - April 2021
- Preliminary support of Intel Alder Lake and Z6xx platform.
- Preliminary support of DDR5 memory.
- AMD Ryzen 5700G, 5600G and 5300G APUs.
- AMD Radeon RX 6900 XT and 6700 XT GPUs.
- Added hotspot and GDDR6 temperatures on NVIDIA GPUs.

--------------------------------------------------------------------------------------------------
1.43 - November 2020
- AMD Ryzen 5000 "Zen 3" Vermeer support.
- AMD Radeon 6800 and 6800 XT GPUs.
- Intel Rocket Lake processors preliminary support.
- Intel Tiger Lake-U and Tiger Lake-H processors.
- Intel Z590 chipset.
- NVIDIA RTX 3090, 3080, 3070 GPUs.

--------------------------------------------------------------------------------------------------
1.42 - September 2020
- AMD Ryzen 9 3900XT, Ryzen 7 3800XT and Ryzen 5 3600XT, Ryzen 7 PRO 4750G, Ryzen 5 PRO 4650G, Ryzen 3 PRO 4350G processors.
- AMD B550 chipset.
- Intel Comet Lake, Tiger Lake processors.
- Intel Z490/W480/B460 chipsets.
- Hygon processors.

--------------------------------------------------------------------------------------------------
1.41 - September 2019
- Intel Cascade Lake and Ice Lake processors.
- NVIDIA RTX 2070 and 2080 Super.
- AMD Threadripper 3000 preliminary support.
- Zhaoxin processors.

--------------------------------------------------------------------------------------------------
1.40 - March 2019
- AMD Radeon VII.
- NVIDIA GTX 1660 and 1660 Ti.

--------------------------------------------------------------------------------------------------
1.39 - February 2019
- NVIDIA GeForce RTX serie 20 (multiple fans).
- Intel Basin Falls Skylake-X refresh.

--------------------------------------------------------------------------------------------------
1.38 - November 2018
- Intel Gemini Lake family.
- Intel Xeon E processors.
- Fix issue with multiple graphics devices.

--------------------------------------------------------------------------------------------------
1.37 - October 2018
- Improved support of Z390 mainboards.
- New performance limits indicators (NVIDIA GPUs)
- Fix GPU utilization bug reported at 0%.

--------------------------------------------------------------------------------------------------
1.36 - September 2018
- AMD Threadripper 2000 processors.
- Intel 9th generation Core family (Coffee Lake 9900K, 9700K, 9600K, 9600, 9500 and 9400).
- Intel Coffee Lake-U processors.
- Preliminary support of ASUS WMI monitoring.

--------------------------------------------------------------------------------------------------
1.35 - April 2018
- AMD Ryzen 2000 processors.
- Intel Xeon Bronze / Silver / Gold / Platinium processors.
- Improved Intel IGP monitoring.
- Improved HDD monitoring.

--------------------------------------------------------------------------------------------------
1.34 - December 2017
- AMD Raven Ridge processors.
- Windows 10 Build 16299.
- Improved NVIDIA GPUs monitoring.

--------------------------------------------------------------------------------------------------
1.33 - October 2017
- Intel Coffee Lake processors and Z370 platform.
- Intel Skylake-X HCC processors.
- Intel Xeon Skylake-SP and Xeon W Skylake processors.

--------------------------------------------------------------------------------------------------
1.32 - August 2017
- Intel Core X processors (KBL-X and SKL-X) and X299 platform.
- AMD ThreadRipper and X399 platform.

--------------------------------------------------------------------------------------------------
1.31 - March 2017
- AMD Ryzen processors.
- AMD Polaris GPU power report.

--------------------------------------------------------------------------------------------------
1.30 - October 2016
- Corsair Hydro series CPU coolers (H80i, H100i, H110i, H115i) support.
- Corsair RMi and AXi series PSUs support.
- NVMe SSDs support.
- Intel Kaby Lake processors.
- AMD Bristol Ridge processors.
- NVIDIA Pascal GPUs (GTX10x0).

--------------------------------------------------------------------------------------------------
1.29 - June 2016
- Intel Broadwell-E/EP processors.
- Intel Skylake Pentium and Celeron.
- AMD Carrizo APUs.
- Adds disks volumes space utilisation.

--------------------------------------------------------------------------------------------------
1.28 - July 2015
- Intel Broadwell and Intel Skylake CPUs.
- Added indivudual CPU load.
- Added NVIDIA TDP percentage

--------------------------------------------------------------------------------------------------
1.27 - March 2015
- Report CPU and GPU clocks.
- Intel Core M CPUs and preliminary support of Intel Skylake.

--------------------------------------------------------------------------------------------------
1.26 - December 2014
- Added CPU and GPU utilization.
- Added DRAM power (Haswell processors).
- Intel X99 Platform (DDR4 and Haswell-E).
- Support for Windows 10.
- New application icon.

--------------------------------------------------------------------------------------------------
1.25 - May 2014
- Intel Haswell-E, Core i7-4770R and Core i5-4570R Crystal Well, Celeron Haswell (G1830, G1820).
- AMD Athlon 5350 & 5150, Sempron 3850 & 2650 (Kabini), A10-7850K, A10-7800, A10-7700K, A8-7600, A6-7400K, A4-7300 (Kaveri), A6-6420K, A4-6320, A4-4020 (Richland).
- Nuvoton NCT6106 and SMSC SCH5636 SIOs (Fujitsu mainboards).
